import AppRoutes from "../routes/index"

export default function Page() {
  return <AppRoutes />
}
